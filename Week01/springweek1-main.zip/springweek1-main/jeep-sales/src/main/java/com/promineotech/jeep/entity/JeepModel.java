/**
 * 
 */
package com.promineotech.jeep.entity;

/**
 * @author D
 *
 */
public enum JeepModel {
  CHEROKEE,
  COMPASS,
  GLADIATOR,
  GRAND_CHEROKEE,
  RENEGADE,
  WRANGLER,
  WRANGLER_4XE
}
