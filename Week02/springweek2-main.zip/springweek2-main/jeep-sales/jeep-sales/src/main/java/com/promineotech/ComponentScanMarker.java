/**
 * 
 */
package com.promineotech;

/**
 * @author D 
 *
 */
public interface ComponentScanMarker {

}
